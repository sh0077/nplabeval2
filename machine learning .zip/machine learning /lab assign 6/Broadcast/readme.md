Run listeners first.
